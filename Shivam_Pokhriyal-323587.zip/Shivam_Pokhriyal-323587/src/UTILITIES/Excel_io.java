package UTILITIES;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Excel_io {
	File f;
	FileInputStream fis;
	XSSFWorkbook wb;
	static XSSFSheet sh;
	static int no_of_rows;
	public String cat;
	public String searchString;
	public int qty;
	public String prod;
	public float total;
	
	public Excel_io(String Sheet) {
		try {
			this.f=new File("C:\\Users\\shivam.pokhriyal\\Documents\\sel-test.xlsx");
			this.fis=new FileInputStream(f);
			this.wb=new XSSFWorkbook(fis);
			sh=wb.getSheet(Sheet);
			no_of_rows=count_row();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	public int count_row() {
		return (sh.getLastRowNum()-sh.getFirstRowNum());	
	}
	
	public ArrayList<Excel_io> read_excel_1() {
		ArrayList<Excel_io> Shop_cart=new ArrayList<Excel_io>();
		
		for(int i=2;i<=no_of_rows;i++) {
			Excel_io Product=new Excel_io("Sheet1");
			    
				XSSFRow row=sh.getRow(i);
				XSSFCell cell=row.getCell(0);
				Product.cat=cell.getStringCellValue();
				cell=row.getCell(1);
				Product.searchString=cell.getStringCellValue();
				cell=row.getCell(2);
				Product.qty=(int) cell.getNumericCellValue();
				Shop_cart.add(Product);
			}
		return Shop_cart;
	}
	
	public ArrayList<Excel_io> read_excel_2() {
		ArrayList<Excel_io> Shop_cart=new ArrayList<Excel_io>();
		
		for(int i=2;i<=no_of_rows;i++) {
			Excel_io Product=new Excel_io("Sheet2");
			    
				XSSFRow row=sh.getRow(i);
				XSSFCell cell=row.getCell(0);
				Product.prod=cell.getStringCellValue();
				cell=row.getCell(1);
				Product.total= (float) cell.getNumericCellValue();
				Shop_cart.add(Product);
			}
		return Shop_cart;
	}
	
}
