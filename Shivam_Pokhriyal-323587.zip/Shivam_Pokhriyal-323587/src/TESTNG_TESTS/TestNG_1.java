package TESTNG_TESTS;




import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Base_classes.Create_log;
import Base_classes.Home_Page;
import Base_classes.Product_Detail_Page;
import Base_classes.Search_Results_Page;
import Base_classes.Shopping_Cart;
import UTILITIES.Excel_io;


public class TestNG_1 {
	WebDriver dr;
	public Home_Page homepage;
	public Search_Results_Page search_res;
	public Product_Detail_Page prod_det;
	public Shopping_Cart cart;
	ArrayList<Excel_io> arrlist=new ArrayList<Excel_io>();
	ArrayList<Excel_io> arrlist_2=new ArrayList<Excel_io>();
	public Create_log logs;
	@BeforeClass
	public void launch() {	
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		this.dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
		 Excel_io ex=new Excel_io("Sheet1");
		 Excel_io ex2=new Excel_io("Sheet2");
		  arrlist=ex.read_excel_1();
		  arrlist_2=ex2.read_excel_2();
		  
	}
	
	
	@Test(priority=0)
	public void Test_1() {
		homepage=new Home_Page(dr);
		logs=new Create_log();
		String av=homepage.getHomeTitle();
		String ev="Online Bookstore";
		 String result;
		  if(av.equals(ev)) {
			  result="pass";
		  }
		  else {
			  result="fail";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(ev, av);
		  sa.assertAll();
		  String name="Test_1";
		  logs.writeLog(name, ev, av, result);
	}
	
	@Test(priority=1)
	public void Test_2() {
		String av=homepage.getsearchprodtext();
		String ev="Search Products";
		 String result;
		  if(av.equals(ev)) {
			  result="pass";
		  }
		  else {
			  result="fail";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(ev, av);
		  sa.assertAll();
		  String name="Test_2";
		  logs.writeLog(name, ev, av, result);
	}
	@Test(priority=2)
	
	public void Test_3(){
		homepage.search_prod(arrlist.get(0).cat, arrlist.get(0).searchString);
		search_res=new Search_Results_Page(dr);
		String av=search_res.getSeachresTitle();
		String ev="SearchResults";
		 String result;
		  if(av.equals(ev)) {
			  result="pass";
		  }
		  else {
			  result="fail";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(ev, av);
		  sa.assertAll();
		  search_res.click_prod();
		  String name="Test_3";
		  logs.writeLog(name, ev, av, result);
	}
	
	
	@Test(priority=3)
	public void Test_4() {
		prod_det= new Product_Detail_Page(dr);
		cart=new Shopping_Cart(dr);
		String av=prod_det.getProddetTitle();
		String ev="ProductDetail";
		 String result;
		  if(av.equals(ev)) {
			  result="pass";
		  }
		  else {
			  result="false";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(av,ev);
		  sa.assertAll();
		  String qty=Integer.toString(arrlist.get(0).qty);
		  prod_det.shop(qty);
		  cart.goHome();
		  String name="Test_4";
		  logs.writeLog(name, ev, av, result);
	
	}
	
	@Test(priority=4)
	
	public void Test_5(){
		homepage.search_prod(arrlist.get(1).cat, arrlist.get(1).searchString);
		  search_res.click_prod();
		  String av=prod_det.getProddetTitle();
			String ev="ProductDetail";
			 String result;
			  if(av.equals(ev)) {
				  result="pass";
			  }
			  else {
				  result="false";
			  }
			  SoftAssert sa=new SoftAssert();
			  sa.assertEquals(av,ev);
			  sa.assertAll();
			  String qty=Integer.toString(arrlist.get(1).qty);
			  prod_det.shop(qty);
			  String name="Test_5";
			  logs.writeLog(name, ev, av, result);
	}
	
/*	@Test(priority=4)
	public void Test_5() {
		cart=new Shopping_Cart(dr);
		String av=cart.verify_prod();
		String ev="";
		 String result;
		  if(av.equals(ev)) {
			  result="pass";
		  }
		  else {
			  result="false";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(av,ev);
		  sa.assertAll();
	}*/
	
/*	@Test(priority=5)
	public void Test_6() {
		String av=cart.verify_total();
		float ex=39.99f;
		String ex1=Float.toString(ex);
		
		String ev="$"+ex1;
		 String result;
		  if(av.equals(ev)) {
			  result="pass";
		  }
		  else {
			  result="false";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(av,ev);
		  sa.assertAll();
		  cart.goHome();
	}*/
	
	
/*	 @Test(priority=1)
	 public void verify_home_page_Title() {
		  homepage=new Home_page(dr);
		  logs=new Create_log();
		  String ar=homepage.getHomeTitle();
		  String er="My Store";
		  String result;
		  if(ar.equals(er)) {
			  result="pass";
		  }
		  else {
			  result="false";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(er, ar);
		  sa.assertAll();
		  String name="verify_home_title";
		  logs.writeLog(name, er, ar, result);
		 
		  System.out.println("Home page title verified");
		 
		  
	 }
	 @Test(priority=2)
	 public void verify_signin_text() {
		  homepage=new Home_page(dr);
		  String ar=homepage.getSigninText();
		  String er="Sign in";
		  String result;
		  if(ar.equals(er)) {
			  result="pass";
		  }
		  else {
			  result="false";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(er, ar);
		  sa.assertAll();
		  String name="verify_signin_text";
		  logs.writeLog(name, er, ar,result );
	 }
	 @Test(priority=3)
	 public void test_signin_click() {
		 homepage=new Home_page(dr);
		 homepage.clickSignin(); 
		 login=new Authentication_class(dr);
		 String ar=login.getLoginTitle();
		  String er="Login - My Store";
		  String result;
		  if(ar.equals(er)) {
			  result="pass";
		  }
		  else {
			  result="fail";
		  }
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(er, ar);
		  sa.assertAll();
		  String name="test_signin_click";
		  logs.writeLog(name, er, ar, result);
	 }*/
  }
