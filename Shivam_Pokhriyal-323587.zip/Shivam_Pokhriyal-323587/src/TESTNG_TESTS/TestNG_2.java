package TESTNG_TESTS;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import UTILITIES.Excel_io;

public class TestNG_2 extends TestNG_1 {
		int i=2;
		int j=2;
	 @Test(priority=5,dataProvider="productprovider")
	 public void Test_6(String prodName) {
		 
		 System.out.println(i);
			String av=cart.verify_prod(i);
			 
			String ev=prodName;
			 String result;
			  if(av.equals(ev)) {
				  result="pass";
			  }
			  else {
				  result="false";
			  }
			  SoftAssert sa=new SoftAssert();
			  sa.assertEquals(av,ev);
			  sa.assertAll();
			 i++;
			 String name="Test_6";
			  logs.writeLog(name, ev, av, result);
		}
	 @Test(priority=6,dataProvider="priceprovider")
	 public void Test_7(String prodPrice) {
		 
		 System.out.println(j);
			String av=cart.verify_total(j);
			 
			String ev=prodPrice;
			 String result;
			  if(av.equals(ev)) {
				  result="pass";
			  }
			  else {
				  result="false";
			  }
			  SoftAssert sa=new SoftAssert();
			  sa.assertEquals(av,ev);
			  sa.assertAll();
			 j++;
			 String name="Test_7";
			  logs.writeLog(name, ev, av, result);
		}
	
	  @DataProvider(name="productprovider")
	  public String[] get_testdata(){
		  String[] prod_name= new String[arrlist_2.size()];
		  int i=0;
		 for(Excel_io product:arrlist_2) 
		 {
			 prod_name[i]= product.prod;  
			 System.out.println(prod_name[i]);
			 i++;
			 
		 }
		  return prod_name;
	  }
	  
	  @DataProvider(name="priceprovider")
	  public String[] get_testdata2(){
		  String[] prod_price= new String[arrlist_2.size()];
		  int i=0;
		 for(Excel_io product:arrlist_2) 
		 {	
			 float price=product.total;
			 prod_price[i]= "$"+Float.toString(price); 
			 System.out.println(prod_price[i]);
			 i++;
			 
		 }
		  return prod_price;
	  }

}
