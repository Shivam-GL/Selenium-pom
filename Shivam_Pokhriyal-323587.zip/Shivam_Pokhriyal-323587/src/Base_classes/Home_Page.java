package Base_classes;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Home_Page{
	WebDriver dr;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[1]/tbody/tr/th")
	WebElement Searchprod;
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select")
	WebElement category;
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[2]/td/input")
	WebElement searchString;
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")
	WebElement searchbtn;
	public Home_Page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public String getHomeTitle() {
		try {
		WebDriverWait wt=new WebDriverWait(dr,10);
		wt.until(ExpectedConditions.titleIs(dr.getTitle()));
		}
		catch(Exception e) {
			System.out.println("element not found");
		}
		String av=dr.getTitle();
		
		return av;
	}
	
	public String getsearchprodtext() {
		return Searchprod.getText();
	}
	
	public void set_cat(String cat_name) {
		Select sel1=new Select(category);
		sel1.selectByVisibleText(cat_name);
	}
	
	public void set_searchString(String searchstring) {
		searchString.sendKeys(searchstring);
	}
	
	public void click_btn() {
		searchbtn.click();
	}
	
	public void search_prod(String c,String v) {
		this.set_cat(c);
		this.set_searchString(v);
		this.click_btn();
	}
	
	
}
