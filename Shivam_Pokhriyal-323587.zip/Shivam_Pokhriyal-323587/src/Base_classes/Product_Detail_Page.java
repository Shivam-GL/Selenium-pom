package Base_classes;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Product_Detail_Page {
	 WebDriver dr;
	 
	 @FindBy(xpath="/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")
		WebElement quantity;
	 @FindBy(xpath="/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")
		WebElement cart_btn;
	 
	 
		public Product_Detail_Page(WebDriver dr) {
			this.dr=dr;
			PageFactory.initElements(dr, this);
		}
		
		public String getProddetTitle() {
			try {
			WebDriverWait wt=new WebDriverWait(dr,10);
			wt.until(ExpectedConditions.titleIs(dr.getTitle()));
			}
			catch(Exception e) {
				System.out.println("element not found");
			}
			String av=dr.getTitle();
			
			return av;
		}
		
		public void set_qty(String qty) {
			quantity.clear();
			quantity.sendKeys(qty);
		}
		
		public void addcart() {
			cart_btn.click();
		}
		
		public void shop(String q) {
			this.set_qty(q);
			this.addcart();
		}
}
