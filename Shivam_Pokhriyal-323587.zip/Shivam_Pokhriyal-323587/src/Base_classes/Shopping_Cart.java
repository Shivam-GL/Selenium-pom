package Base_classes;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Shopping_Cart {
	
	 WebDriver dr;
	 
	
	 @FindBy(xpath="//a[@href=\"Default.php\"]")
		WebElement Home;
	 
	 
		public Shopping_Cart(WebDriver dr) {
			this.dr=dr;
			PageFactory.initElements(dr, this);
		}
		
		public String verify_prod(int i) {
			String prod_name=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+i+"]/td[1]")).getText();
			return prod_name;
		}
		public String verify_total(int j) {
			String prod_price=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+j+"]/td[4]")).getText();
			return prod_price;
		}
		
		public void goHome() {
			Home.click();
		}
}
